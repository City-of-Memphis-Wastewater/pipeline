# Auto-generated version file – DO NOT EDIT
__version__ = "0.3.68"
__git__ = "1b55d3c"
__build_time__ = "2025-11-15T08:03:10.886729"
