# pipeline/interface/cli-eds.py

# PLACEHOLDER
# SEE CHANGELOG.md entry **[0.3.53]** (https://github.com/City-of-Memphis-Wastewater/pipeline/blob/main/docs/CHANGELOG.md#0353---2025-10-24)
# SEE [Issue 44](https://github.com/City-of-Memphis-Wastewater/pipeline/issues/44)

# CONTINUE TO DEVELOP **[cli.py]** (https://github.com/City-of-Memphis-Wastewater/pipeline/blob/main/src/pipeline/cli.py) UNTIL A SMOOTH MOVE CAN BE MADE FROM **[cli.py]** (https://github.com/City-of-Memphis-Wastewater/pipeline/blob/main/src/pipeline/cli.py) TO **[cli-eds.py]** (https://github.com/City-of-Memphis-Wastewater/pipeline/blob/main/src/pipeline/cli/cli-eds.py)
# DO THIS AFTER PROOF OF CONCEPT AND PATTERNS HAVE BEEN USED FOR A STABLE **[cli-mission.py]** (https://github.com/City-of-Memphis-Wastewater/pipeline/blob/main/src/pipeline/cli/cli-mission.py)


